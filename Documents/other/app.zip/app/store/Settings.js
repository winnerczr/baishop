/**
 * Store for keeping Baishop app settings
 */
Ext.define('Baishop.store.Settings', {
    extend: 'Ext.data.Store',
    model: 'Baishop.model.Setting'
});
