/**
 * Favorites Store
 */
Ext.define('Baishop.store.Favorites', {
    extend: 'Ext.data.Store',
    model: 'Baishop.model.Favorite'
});
